// Splash/loading screen
window.onload = () => {
  setTimeout(() => {
    document.getElementById('loading').style.display = 'none';
    document.getElementById('main-content').style.display = 'block';
  }, 3000); // 3 detik loading
};

// Install APK
function installGame(file) {
  window.location.href = `assets/${file}`;
}